package service;

import java.sql.Date;
import java.util.Calendar;

public class OnlineVotingService {

	public static Date addDays(Date d,int noOfDays)
	{
		Calendar c = Calendar.getInstance();
        c.setTime(d);
        c.add(Calendar.DATE, noOfDays);
        return new Date(c.getTimeInMillis());
	}
	
	public static boolean validateUserCollegeID(String userCollegeID)
	{
		if(userCollegeID.substring(0, 2).equals("c0"))
		{
			String uniquePart=userCollegeID.substring(2);
			if(uniquePart.length()==6)
			{
				
				try
				{
					Integer.parseInt(uniquePart);
					return true;
				}
				catch(NumberFormatException e)
				{
					return false;
				}
			}
		}
		return false;
	}
	
}
