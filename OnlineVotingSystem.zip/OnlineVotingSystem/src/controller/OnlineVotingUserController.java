package controller;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Scanner;

import bean.OnlineVotingUserBean;
import database.OnlineVotingDao;
import service.OnlineVotingMailService;
import service.OnlineVotingService;

public class OnlineVotingUserController {
	
	static Scanner sc=new Scanner(System.in);
	static OnlineVotingDao votingDao=new OnlineVotingDao();
	
	public static void userLogin() throws Exception
	{
		Date userDate=votingDao.getUserRegistrationLastDate();
		if(userDate==null)
		{
			System.out.println("Still the election dates are not finalized!!!Please come after some time");
		}
		else
		{
			Date candidateRegEndDate=OnlineVotingService.addDays(userDate,10);
			Date electionPrepareDate=OnlineVotingService.addDays(candidateRegEndDate,5);
			Date electionDate=OnlineVotingService.addDays(candidateRegEndDate,10);
			Date currDate=new Date(Calendar.getInstance().getTime().getTime());
			//electionDate=currDate;
			if(currDate.compareTo(userDate)<=0)
			{
				userRegPage(userDate);
			}
			else if(currDate.compareTo(candidateRegEndDate)<=0)
			{
				candidateRegPage(candidateRegEndDate);
			}
			else if(currDate.compareTo(electionPrepareDate)<=0)
			{
				userElectionPreparePage(electionPrepareDate,electionDate);
			}
			else if(currDate.compareTo(electionDate)==0)
			{
					userElectionDayPage();
			}
			else
			{
					userElectionResultsPage();
			}
		}
		return ;
	}

	private static void userElectionResultsPage() {

		System.out.println("Enter college ID:");
		String collegeID=sc.next();
		System.out.println("Enter password:");
		String password=sc.next();
		String username=votingDao.checkUserCredentials(collegeID,password);
		if(username!=null)
		{
			System.out.println("Welcome "+username);
			int randomNum = (int) ((Math.random()*((9999-1000)+1))+1000);
			OnlineVotingMailService mail=new OnlineVotingMailService();
			String message="Hi,\n\nYour one time password for login is:"+randomNum+"\n\ndon't share with anyone\n\nThanks,\nAdmin";
			mail.sendMail(collegeID+"@mylambton.ca", "One time password for login", message);
			System.out.println("\n Hi "+username+", an OTP has been sent to your mail, please enter OTP to continue:");
			int checkRandomNum=sc.nextInt();
			if(randomNum==checkRandomNum)
			{
				userElectionResultsMainPage();
			}
			else
			{
				System.out.println("\n\n Wrong OTP, you have only one chance left, please enter OTP to continue:");
				checkRandomNum=sc.nextInt();
				if(randomNum==checkRandomNum)
				{
					userElectionResultsMainPage();
				}
				else
				{
					System.out.println("\n\nSorry !!! login again to continue\n\n");
					return;
				}
			}
		
		}
		else
		{
			System.out.println("Incorrect credentials");
		}
				
			
	}

	private static void userElectionResultsMainPage() {
		List<String> results=votingDao.getElectionResults();
		for(String result:results)
		{
			System.out.println(result);
		}
	}

	private static void userElectionDayPage() {
		System.out.println("Enter college ID:");
		String collegeID=sc.next();
		System.out.println("Enter password:");
		String password=sc.next();
		String username=votingDao.checkUserCredentials(collegeID,password);
		if(username!=null)
		{
			System.out.println("Welcome "+username);
			int randomNum = (int) ((Math.random()*((9999-1000)+1))+1000);
			OnlineVotingMailService mail=new OnlineVotingMailService();
			String message="Hi,\n\nYour one time password for login is:"+randomNum+"\n\ndon't share with anyone\n\nThanks,\nAdmin";
			mail.sendMail(collegeID+"@mylambton.ca", "One time password for login", message);
			System.out.println("\n Hi "+username+", an OTP has been sent to your mail, please enter OTP to continue:");
			int checkRandomNum=sc.nextInt();
			if(randomNum==checkRandomNum)
			{
				userElectionDayMainPage(collegeID,username);
			}
			else
			{
				System.out.println("\n\n Wrong OTP, you have only one chance left, please enter OTP to continue:");
				checkRandomNum=sc.nextInt();
				if(randomNum==checkRandomNum)
				{
					userElectionDayMainPage(collegeID,username);
				}
				else
				{
					System.out.println("\n\nSorry !!! login again to continue\n\n");
					return;
				}
			}
		
		}
		else
		{
			System.out.println("Incorrect credentials");
		}
				
	}

	private static void userElectionDayMainPage(String collegeID, String username) {
		if(votingDao.checkUserVotedAlready(collegeID))
		{
			System.out.println("Hi "+username+", You have already casted your vote, please login tommorrow to see the election results");
		}
		else
		{
			List<OnlineVotingUserBean>	candidateList=votingDao.getCandidateList();
			if(candidateList!=null)
			{
				List<String> candidateIDs=new ArrayList<String>();
				for(OnlineVotingUserBean candidate:candidateList)
				{
					candidateIDs.add(candidate.getUserCollegeID());
				}
				while(true)
				{
					System.out.println("Below are the list of candidates participating in the election:");
					System.out.println("CandidateID    candidatename");
					for(OnlineVotingUserBean candidate:candidateList)
					{
						System.out.println(candidate.getUserCollegeID()+"  "+candidate.getUsername());
					}
					System.out.println("Please enter candidateID to cast your vote");
					String candidateID1=sc.next();
					if(candidateIDs.contains(candidateID1))
					{
						System.out.println("Confirm your selection by entering candidate ID again:");
						String candidateID2=sc.next();
						if(candidateID1.equalsIgnoreCase(candidateID2))
						{
							votingDao.castVoteUpdate(candidateID1,collegeID,username);
							System.out.println("You have successfully casted your vote, please come back tommorrow to see the results");
							break;
						}
						else
						{
							System.out.println("Mismatch in candidateID's");
						}
					}
					else
					{
						System.out.println("Wrong selection");
					}
				}
			}
		}
		
	}

	private static void userElectionPreparePage(Date electionPrepareDate, Date electionDate) {

		System.out.println("Enter college ID:");
		String collegeID=sc.next();
		System.out.println("Enter password:");
		String password=sc.next();
		String username=votingDao.checkUserCredentials(collegeID,password);
		if(username!=null)
		{
			System.out.println("Welcome "+username);
			int randomNum = (int) ((Math.random()*((9999-1000)+1))+1000);
			OnlineVotingMailService mail=new OnlineVotingMailService();
			String message="Hi,\n\nYour one time password for login is:"+randomNum+"\n\ndon't share with anyone\n\nThanks,\nAdmin";
			mail.sendMail(collegeID+"@mylambton.ca", "One time password for login", message);
			System.out.println("\n Hi "+username+", an OTP has been sent to your mail, please enter OTP to continue:");
			int checkRandomNum=sc.nextInt();
			if(randomNum==checkRandomNum)
			{
				electionRegMainPage(collegeID,username);
			}
			else
			{
				System.out.println("\n\n Wrong OTP, you have only one chance left, please enter OTP to continue:");
				checkRandomNum=sc.nextInt();
				if(randomNum==checkRandomNum)
				{
					electionRegMainPage(collegeID,username);
				}
				else
				{
					System.out.println("\n\nSorry !!! login again to continue\n\n");
					return;
				}
			}
		
		}
		else
		{
			System.out.println("Incorrect credentials");
		}
			
			
	}

	private static void electionRegMainPage(String collegeID, String username) {
		if(votingDao.checkCandidateReg(collegeID))
		{
			System.out.println("Welcome candidate!!!");
			while(true)
			{
				System.out.println("Please choose option 1.See list of candidates participating in election    2.Send custom message to all users 3.exit");
				int choice=sc.nextInt();
				if(choice==1)
				{
					seeListOfCandidates();
				}
				else if(choice==2)
				{
					List<OnlineVotingUserBean> userList=votingDao.getListOfUsers(2);
					if(userList==null)
					{
						System.out.println("There are no users avaliable");
					}
					else
					{
						OnlineVotingMailService mail=new OnlineVotingMailService();
						System.out.println("Enter message to send to users:");
						sc.nextLine();
						String message1=sc.nextLine();
						for(OnlineVotingUserBean userBean:userList)
						{										
							String message="Hi "+userBean.getUsername()+",\n"+message1+"\n\nThanks,\n"+username;
							mail.sendMail(userBean.getUserCollegeID()+"@mylambton.ca", "New notification from online voting system", message);
						}
					}
				}
				else if(choice==3)
				{
					return;
				}
				else
				{
					System.out.println("Incorrect choice");
				}
			}
		
		}
		else
		{
			System.out.println("Welcome user!!!");
			while(true)
			{
				System.out.println("Please choose option 1.See list of candidates participating in election 2.exit");
				int choice=sc.nextInt();
				if(choice==1)
				{
					seeListOfCandidates();
				}
				else if(choice==2)
				{
					break;
				}
				else
				{
					System.out.println("Incorrect choice");
				}
			}
		}
				
	}

	private static void seeListOfCandidates() {
		List<OnlineVotingUserBean>	candidateList=votingDao.getCandidateList();
		if(candidateList.size()>0)
		{
			System.out.println("List of candidates participating in election");
			System.out.println("candidateID     CandidateName");
			for(OnlineVotingUserBean userBean : candidateList)
			{
				System.out.println(userBean.getUserCollegeID()+"    "+userBean.getUsername());
			}
		}
		else
		{
			System.out.println("There are candidates standing in the election");
		}
	}

	private static void candidateRegPage(Date candidateRegEndDate) {
		System.out.println("Enter college ID:");
		String collegeID=sc.next();
		System.out.println("Enter password:");
		String password=sc.next();
		String username=votingDao.checkUserCredentials(collegeID,password);
		if(username!=null)
		{
			System.out.println("Welcome "+username);
			int randomNum = (int) ((Math.random()*((9999-1000)+1))+1000);
			OnlineVotingMailService mail=new OnlineVotingMailService();
			String message="Hi,\n\nYour one time password for login is:"+randomNum+"\n\ndon't share with anyone\n\nThanks,\nAdmin";
			mail.sendMail(collegeID+"@mylambton.ca", "One time password for login", message);
			System.out.println("\n Hi "+username+", an OTP has been sent to your mail, please enter OTP to continue:");
			int checkRandomNum=sc.nextInt();
			if(randomNum==checkRandomNum)
			{
				candidataRegMainPage(collegeID,password,username);
			}
			else
			{
				System.out.println("\n\n Wrong OTP, you have only one chance left, please enter OTP to continue:");
				checkRandomNum=sc.nextInt();
				if(randomNum==checkRandomNum)
				{
					candidataRegMainPage(collegeID,password,username);
				}
				else
				{
					System.out.println("\n\nSorry !!! login again to continue\n\n");
					return;
				}
			}
		
		}
		else
		{
			System.out.println("Incorrect credentials");
		}
			
	}
	
	private static void candidataRegMainPage(String collegeID, String password, String username) {
		if(votingDao.checkCandidateReg(collegeID))
		{			
			while(true)
			{
				System.out.println("You have already registered as a candidate in election!!! Do you want to opt out[yes/no]");
				String choice=sc.next();
				if(choice.equalsIgnoreCase("yes"))
				{
					votingDao.candidateUserReg(collegeID,2);
					System.out.println("You are now unregistered as a candidate!!!you are now logged out");
					break;
				}
				else if(choice.equalsIgnoreCase("no"))
				{
					System.out.println("You are still a candidate participating in election!!!you are now logged out");
					break;
				}
				else
				{
					System.out.println("bad option");
				}
			}
		}
		else
		{
			while(true)
			{
				System.out.println("Do you want to register as a candidate in election [yes/no]");
				String choice=sc.next();
				if(choice.equalsIgnoreCase("yes"))
				{
					votingDao.candidateUserReg(collegeID,1);
					System.out.println("You are now a candidate participating in election!!!you are now logged out");
					break;
				}
				else if(choice.equalsIgnoreCase("no"))
				{
					System.out.println("Thank you, you are not registered as a candidate in election!!!you are now logged out");
					break;
				}
				else
				{
					System.out.println("bad option");
				}
			}
		}
		
	}

	private static void userRegMainPage(String userCollegeID)
	{
		int randomNum = (int) ((Math.random()*((9999-1000)+1))+1000);
		OnlineVotingMailService mail=new OnlineVotingMailService();
		String message="Hi,\n\nYour one time password for login is:"+randomNum+"\n\ndon't share with anyone\n\nThanks,\nAdmin";
		mail.sendMail(userCollegeID+"@mylambton.ca", "One time password for login", message);
		System.out.println("\n Hi user, an OTP has been sent to your mail, please enter OTP to continue:");
		int checkRandomNum=sc.nextInt();
		if(randomNum==checkRandomNum)
		{
			getUserLoginDetails(userCollegeID);
		}
		else
		{
			System.out.println("\n\n Wrong OTP, you have only one chance left, please enter OTP to continue:");
			checkRandomNum=sc.nextInt();
			if(randomNum==checkRandomNum)
			{
				getUserLoginDetails(userCollegeID);
			}
			else
			{
				System.out.println("\n\nSorry !!! start from beginning\n\n");
				return;
			}
		}
	}
	
	private static void getUserLoginDetails(String collegeID)
	{
		System.out.println("Please enter username:");
		String username=sc.next();
		String password;
		while(true)
		{
			System.out.println("Please enter password(case sensitive):");
			password=sc.next();
			System.out.println("Please confirm password:");
			String confirmPassword=sc.next();
			if(password.equals(confirmPassword))
			{
				break;
			}
			else
			{
				System.out.println("Attention!!! Passwords do not match");
			}
		}
		votingDao.addUserDetails(collegeID,username,password);
	}

	private static void userRegPage(Date userDate) {
		System.out.println("Welcome to user registration page!!!");
		while(true)
		{
			System.out.println("Please select option to continue\t1.User registration\t2.User login\t3.Exit");
			int optionSelected=sc.nextInt();
			if(optionSelected==1)
			{
				System.out.println("Enter your college ID to continue");
				String userCollegeID=sc.next();
				if(OnlineVotingService.validateUserCollegeID(userCollegeID))
				{
					if(!votingDao.userRegistrationCheck(userCollegeID))
					{
						if(votingDao.userNewRegistrationCheck(userCollegeID))
						{
							userRegMainPage(userCollegeID);
							System.out.println("Registration sucessfull");
						}
						else
						{
							System.out.println("you had already registered!!! Please login");
						}
					}
					else
					{
						System.out.println("Your ID not yet registered in database!!! Please contact admin");
					}
				}
				else
				{
					System.out.println("Incorrect college ID format, correct format(ex:c0761296)");
				}
			}
			else if(optionSelected==2)
			{
				System.out.println("Enter college ID:");
				String collegeID=sc.next();
				System.out.println("Enter password:");
				String password=sc.next();
				String username=votingDao.checkUserCredentials(collegeID,password);
				if(username!=null)
				{
					System.out.println("Welcome "+username);
					int randomNum = (int) ((Math.random()*((9999-1000)+1))+1000);
					OnlineVotingMailService mail=new OnlineVotingMailService();
					String message="Hi,\n\nYour one time password for login is:"+randomNum+"\n\ndon't share with anyone\n\nThanks,\nAdmin";
					mail.sendMail(collegeID+"@mylambton.ca", "One time password for login", message);
					System.out.println("\n Hi "+username+", an OTP has been sent to your mail, please enter OTP to continue:");
					int checkRandomNum=sc.nextInt();
					if(randomNum==checkRandomNum)
					{
						System.out.println("You are logged in successfully!!!Please come back after "+OnlineVotingService.addDays(userDate, 10)+" to register/un-register as candidate to participate in election");
					}
					else
					{
						System.out.println("\n\n Wrong OTP, you have only one chance left, please enter OTP to continue:");
						checkRandomNum=sc.nextInt();
						if(randomNum==checkRandomNum)
						{
							System.out.println("You are logged in successfully!!!Please come back after "+OnlineVotingService.addDays(userDate, 10)+" to register/un-register as candidate to participate in election");
						}
						else
						{
							System.out.println("\n\nSorry !!! login again to continue\n\n");
							return;
						}
					}
				
				}
				else
				{
					System.out.println("Incorrect credentials");
				}
			}
			else if(optionSelected==3)
			{
				return;
			}
			else
			{
				System.out.println("select appropriate option");
			}
		}
	}
	
	
}
