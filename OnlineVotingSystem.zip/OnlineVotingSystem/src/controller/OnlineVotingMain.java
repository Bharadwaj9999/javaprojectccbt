package controller;

import java.util.Scanner;


public class OnlineVotingMain {

	static Scanner sc=new Scanner(System.in);
	
	public static void main(String args[])
	{
		System.out.println("Welcome to Online voting system\n\n");
		while(true)
		{
			try
			{
				System.out.println("1.Admin login\t2.User login\t3.Exit");
				int option=sc.nextInt();
				if(option==1)
				{
					OnlineVotingAdminController.adminLogin();
				}
				else if(option==2)
				{
					OnlineVotingUserController.userLogin();
				}
				else if(option==3)
				{
					break;
				}
				else
				{
					System.out.println("\n\nMake appropriate selection\n\n");
				}
			}
			catch(Exception E)
			{
				System.out.println("Error in the system, please try again"+E.getMessage());
			}
		}
		
	}
	
}
