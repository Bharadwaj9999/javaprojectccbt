package controller;

import java.sql.Date;
import java.util.Calendar;
import java.util.List;
import java.util.Scanner;

import bean.OnlineVotingUserBean;
import database.OnlineVotingDao;
import service.OnlineVotingMailService;
import service.OnlineVotingService;

public class OnlineVotingAdminController {
	
	static Scanner sc=new Scanner(System.in);
	static OnlineVotingDao votingDao=new OnlineVotingDao();
	
	public static void adminLogin() 
	{
		System.out.println("\n welcome to admin page, please enter credentials to login\n");
		System.out.println("Username:");
		String username=sc.next();
		System.out.println("\nPassword:");
		String password=sc.next();
		if(username.equals("admin") && password.equals("admin"))
		{
			int randomNum = (int) ((Math.random()*((9999-1000)+1))+1000);
			OnlineVotingMailService mail=new OnlineVotingMailService();
			String message="Hi,\n\nYour one time password for login is:"+randomNum+"\n\ndon't share with anyone\n\nThanks,\nAdmin";
			mail.sendMail("donotreply.onlinevoting@gmail.com", "One time password for login", message);
			System.out.println("\n Hi Admin, an OTP has been sent to your mail, please enter OTP to continue:");
			int checkRandomNum=sc.nextInt();
			if(randomNum==checkRandomNum)
			{
				adminMain();
			}
			else
			{
				System.out.println("\n\n Wrong OTP, you have only one chance left, please enter OTP to continue:");
				checkRandomNum=sc.nextInt();
				if(randomNum==checkRandomNum)
				{
					adminMain();
				}
				else
				{
					System.out.println("\n\nSorry !!! login again to continue\n\n");
					return;
				}
			}
		}
		return ;
	}
	
	public static void adminMain()
	{
		Date currDate=new Date(Calendar.getInstance().getTime().getTime());
		Date userDate=votingDao.getUserRegistrationLastDate();
		if(userDate==null)
		{
			System.out.println("Please enter the last date for user registration in the format(yyyy-mm-dd)");
			String da=sc.next();
			userDate=Date.valueOf(da);
			while(true)
			{
				if(userDate.compareTo(currDate)<=0)
				{
					System.out.println("User reg end date cant be less than current date!!! Please enter valid user reg end date:");
					da=sc.next();
					userDate=Date.valueOf(da);
				}
				else if(userDate.compareTo(OnlineVotingService.addDays(currDate,30))>=0) {
					System.out.println("User reg end date cant be 30 days more than current date!!! Please enter valid user reg end date:");
					da=sc.next();
					userDate=Date.valueOf(da);
				}
				else
				{
					break;
				}
			}
			votingDao.enterUserRegistrationLastDate(userDate);
		}
		Date candidateRegEndDate=OnlineVotingService.addDays(userDate,10);
		Date electionPrepareDate=OnlineVotingService.addDays(candidateRegEndDate,5);
		Date electionDate=OnlineVotingService.addDays(candidateRegEndDate,10);
		//electionDate=currDate;
		if(currDate.compareTo(userDate)<=0)
		{
			adminUserRegPage(userDate);
		}
		else if(currDate.compareTo(candidateRegEndDate)<=0)
		{
			adminCandidateRegPage(candidateRegEndDate);
		}
		else if(currDate.compareTo(electionPrepareDate)<=0)
		{
			adminElectionPreparePage(electionPrepareDate,electionDate);
		}
		else if(currDate.compareTo(electionDate)==0)
		{
				adminElectionDayPage();
		}
		else
		{
				adminElectionResultsPage();
		}
	}
	
	private static void adminElectionResultsPage() {
		
	}

	private static void adminElectionDayPage() {
		System.out.println("Admin!!! Election is going on");
		while(true)
		{
			System.out.println("\nPlease select option to continue\t1.Send notification to users who not yet voted\t2.exit");
			int optionSelected=sc.nextInt();
			if(optionSelected==1)
			{
				List<OnlineVotingUserBean> unRegisteredUserList=votingDao.getListOfUsers(5);
				if(unRegisteredUserList==null)
				{
					System.out.println("All users casted their votes");
				}
				OnlineVotingMailService mail=new OnlineVotingMailService();
				for(OnlineVotingUserBean userBean:unRegisteredUserList)
				{					
					String message="Hi,\n\nElection day is up, please log into system to cast your vote\n\nThanks,\nAdmin";
					mail.sendMail(userBean.getUserCollegeID()+"@mylambton.ca", "New notification from online voting system", message);
				}
			}
			else if(optionSelected==2)
			{
				return;
			}
			else
			{
				System.out.println("Enter appropriate option");
			}
		}
	}

	private static void adminElectionPreparePage(Date electionPrepareDate,Date electionDate) {
		System.out.println("Admin!!! Welcome to election preparation date");
		while(true)
		{
			System.out.println("\nPlease select option to continue\n\n1.See list of registered users\t2.See list of candidates\t3.Send notification to candidates\t4.Send notification to users\t5.Send custom message to user\t6.Send custom message to candidate\t7.Exit");
			int optionSelected=sc.nextInt();
			if(optionSelected==1)
			{
				List<OnlineVotingUserBean> listOfUsers=votingDao.getListOfUsers(2);
				if(listOfUsers==null)
				{
					System.out.println("Sorry no users registered in system");
				}
				else
				{
					System.out.println("List of users registered in system");
					System.out.println("\tUserName\tUserCollegeID\tUserMailID");
					for(OnlineVotingUserBean userBean:listOfUsers)
					{
						System.out.println("\t"+userBean.getUsername()+"\t"+userBean.getUserCollegeID()+"\t"+userBean.getUserMailID());
					}
				}
			}
			else if(optionSelected==2)
			{
				List<OnlineVotingUserBean> candidateList=votingDao.getListOfUsers(4);
				if(candidateList==null)
				{
					System.out.println("Sorry no candidates registered for election");
				}
				else
				{
					System.out.println("List of candidates registered for election");
					System.out.println("\tCandidateName\tCandidateCollegeID\tCandidateMailID");
					for(OnlineVotingUserBean userBean:candidateList)
					{
						System.out.println("\t"+userBean.getUsername()+"\t"+userBean.getUserCollegeID()+"\t"+userBean.getUserMailID());
					}
				}
			}
			else if(optionSelected==3)
			{
				List<OnlineVotingUserBean> registeredCandidateList=votingDao.getListOfUsers(4);
				if(registeredCandidateList==null)
				{
					System.out.println("There are no candidates registered for the election");
				}
				else
				{
					OnlineVotingMailService mail=new OnlineVotingMailService();
					for(OnlineVotingUserBean userBean:registeredCandidateList)
					{					
						String message="Hi Candidate,\n\nElection day is coming up, the last day for campaign is:"+electionPrepareDate+" \n\nAll the best\n\nThanks,\nAdmin";
						mail.sendMail(userBean.getUserCollegeID()+"@mylambton.ca", "New notification from online voting system", message);
					}
				}
			}
			else if(optionSelected==4)
			{
				List<OnlineVotingUserBean> unRegisteredUserList=votingDao.getListOfUsers(2);
				if(unRegisteredUserList==null)
				{
					System.out.println("There are no users in the system");
				}
				else
				{
					OnlineVotingMailService mail=new OnlineVotingMailService();
					for(OnlineVotingUserBean userBean:unRegisteredUserList)
					{					
						String message="Hi,\n\nElection day is coming up, date of election:"+electionDate+"\n\nThanks,\nAdmin";
						mail.sendMail(userBean.getUserCollegeID()+"@mylambton.ca", "New notification from online voting system", message);
					}
				}
			}
			else if(optionSelected==5)
			{
				adminCustomMessageToUser(2);
			}
			else if(optionSelected==6)
			{
				adminCustomMessageToUser(1);
			}
			else if(optionSelected==7)
			{
				return;
			}
			else
			{
				System.out.println("Enter appropriate option");
			}
		}
	}

	public static void adminUserRegPage(Date userDate)
	{
		System.out.println("Admin!!! Welcome to user page");
		while(true)
		{
			System.out.println("\nPlease select option to continue\n\n1.See list of users\t2.See list of registered users\t3.Add new user\t4.Send message to a user\t5.exit");
			int optionSelected=sc.nextInt();
			if(optionSelected==1)
			{
				List<OnlineVotingUserBean> listOfUsers=votingDao.getListOfUsers(1);
				if(listOfUsers==null)
				{
					System.out.println("Sorry no users available in system");
				}
				else
				{
					System.out.println("List of users added into system");
					System.out.println("\tUserCollegeID\tUserMailID");
					for(OnlineVotingUserBean userBean:listOfUsers)
					{
						System.out.println("\t"+userBean.getUserCollegeID()+"\t"+userBean.getUserMailID());
					}
				}
			}
			else if(optionSelected==2)
			{
				List<OnlineVotingUserBean> listOfUsers=votingDao.getListOfUsers(2);
				if(listOfUsers==null)
				{
					System.out.println("Sorry no users registered in system");
				}
				else
				{
					System.out.println("List of users registered in system");
					System.out.println("\tUserName\tUserCollegeID\tUserMailID");
					for(OnlineVotingUserBean userBean:listOfUsers)
					{
						System.out.println("\t"+userBean.getUsername()+"\t"+userBean.getUserCollegeID()+"\t"+userBean.getUserMailID());
					}
				}
			}
			else if(optionSelected==3)
			{
				while(true)
				{
					System.out.println("Please enter user's college ID or enter exit to exit");
					String userCollegeID=sc.next();
					if(userCollegeID.equalsIgnoreCase("exit"))
					{
						
					}
					else if(OnlineVotingService.validateUserCollegeID(userCollegeID))
					{
						if(votingDao.duplicateUserCheck(userCollegeID,1))
						{
							votingDao.adminAddUser(userCollegeID+"@mylambton.ca", userCollegeID);
							OnlineVotingMailService mail=new OnlineVotingMailService();
							String message="Hi,\n\nYou have been added to online voting system\n\nPlease login to register before"+userDate+"\n\nThanks,\nAdmin";
							mail.sendMail(userCollegeID+"@mylambton.ca", "New notification from online voting system", message);
							break;
						}
						else
						{
							System.out.println("User already exists");
						}
					}
					else
					{
						System.out.println("Invalid user college id format (valid format ex:c0761296)");
					}
				}
			}
			else if(optionSelected==4)
			{
				adminCustomMessageToUser(1);
			}
			else if(optionSelected==5)
			{
				return;
			}
			else
			{
				System.out.println("\nEnter appropriate option");
			}
		}
	}
	
	public static void adminCustomMessageToUser(int option)
	{
		while(true)
		{
			if(option==1)
			{
				System.out.println("Please enter user's college ID or enter exit to exit");
			}
			else if(option==2)
			{
				System.out.println("Please enter candidate ID or enter exit to exit");
			}
			String userCollegeID=sc.next();
			if(userCollegeID.equals("exit"))
			{
				return;
			}
			if(OnlineVotingService.validateUserCollegeID(userCollegeID))
			{
				if(!votingDao.duplicateUserCheck(userCollegeID,option))
				{
					OnlineVotingMailService mail=new OnlineVotingMailService();
					System.out.println("Enter message to be sent:\n");
					sc.nextLine();
					String message=sc.nextLine();
					String totalMessage="Hi,\n\n"+message+"\n\nThanks,\nAdmin";
					mail.sendMail(userCollegeID+"@mylambton.ca", "New notification from online voting system", totalMessage);
					break;
				}
				else
				{
					
					if(option==1)
					{
						System.out.println("User doesnot exist!!!Please enter valid user college ID");
					}
					else if(option==2)
					{
						System.out.println("candidate doesnot exist!!!Please enter valid candidate ID");
					}
				}
			}
			else
			{
				if(option==1)
				{
					System.out.println("Invalid user college id format (valid format ex:c0761296)");
				}
				else if(option==2)
				{
					System.out.println("Invalid candidate id format (valid format ex:c0761296)");
				}
			}
		}
	}
	
	public static void adminCandidateRegPage(Date candidateRegEndDate)
	{
		System.out.println("Admin!!! Candidate registration is going on");
		while(true)
		{
			System.out.println("Please select option to continue\n1.Send notification to user to register as candidate\t2.See list of candidates\t3.Send custom mail to candidates\t4.Send custom mail to user\t5.Exit");
			int option=sc.nextInt();
			if(option==1)
			{
				List<OnlineVotingUserBean> unRegisteredUserList=votingDao.getListOfUsers(3);
				if(unRegisteredUserList==null)
				{
					System.out.println("There are no more users to register as candidate");
				}
				OnlineVotingMailService mail=new OnlineVotingMailService();
				for(OnlineVotingUserBean userBean:unRegisteredUserList)
				{					
					String message="Hi,\n\nCandidate registration is going on...\n\nPlease login to register before "+candidateRegEndDate+" to see list of candidates or register yourself as a candidate\n\nThanks,\nAdmin";
					mail.sendMail(userBean.getUserCollegeID()+"@mylambton.ca", "New notification from online voting system", message);
				}
			}
			else if(option==2)
			{
				List<OnlineVotingUserBean> candidateList=votingDao.getListOfUsers(4);				
				if(candidateList==null)
				{
					System.out.println("Sorry no candidates registered for election");
				}
				else
				{
					System.out.println("List of candidates registered for election");
					System.out.println("\tCandidateName\tCandidateCollegeID\tCandidateMailID");
					for(OnlineVotingUserBean userBean:candidateList)
					{
						System.out.println("\t"+userBean.getUsername()+"\t"+userBean.getUserCollegeID()+"\t"+userBean.getUserMailID());
					}
				}
			}
			else if(option==3)
			{
				adminCustomMessageToUser(2);
			}
			else if(option==4)
			{
				adminCustomMessageToUser(1);
			}
			else if(option==5)
			{
				return;
			}
			else
			{
				System.out.println("\nEnter appropriate option");
			}
		}
	}

}
